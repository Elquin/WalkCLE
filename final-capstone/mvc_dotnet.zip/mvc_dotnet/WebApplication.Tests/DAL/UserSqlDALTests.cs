﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;

namespace WebApplication.Tests.DAL
{
    [TestClass]
    public class UserSqlDALTests
    {

    }
}
